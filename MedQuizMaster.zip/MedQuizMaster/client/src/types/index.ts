// User related types
export interface User {
  id: string;
  email: string;
  displayName: string;
  createdAt: string;
  totalAttempts: number;
  correctAnswers: number;
  streak: number;
  maxStreak: number;
  lastQuizDate: string | null;
  categoryStats: Record<string, CategoryStat>;
}

export interface CategoryStat {
  attempts: number;
  correct: number;
}

// Quiz related types
export interface Category {
  name: string;
  subcategories: string[];
}

export interface Question {
  id: number;
  question: string;
  answer: boolean;
  explanation: string;
  ai_explanation: string | null;
  references: Record<string, string>;
  category: string;
  subcategory?: string;
}

export interface QuizResult {
  question: Question;
  userAnswer: boolean;
  isCorrect: boolean;
}

// Image Quiz related types
export interface ImageQuestion {
  id: string;
  imageUrl: string;
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  category: string;
  subcategory: string;
}

export interface ImageQuizResult {
  question: ImageQuestion;
  userAnswer: string;
  isCorrect: boolean;
}

// Leaderboard related types
export interface LeaderboardEntry {
  userId: string;
  displayName: string;
  accuracy: number;
  attempts: number;
  correct: number;
  streak?: number;
}

// AI Tutor related types
export interface AiTutorQuestion {
  id: string;
  question: string;
  answer: string;
  timestamp: string;
  userId: string;
}

// Achievement related types
export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  condition: {
    type: 'totalQuizzes' | 'streak' | 'accuracy' | 'category';
    threshold: number;
    category?: string;
  };
}
