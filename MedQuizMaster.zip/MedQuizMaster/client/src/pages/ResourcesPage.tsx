import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ArrowLeft, 
  Book, 
  BookOpen, 
  FileText, 
  Link as LinkIcon, 
  ExternalLink,
  Video, 
  Download
} from "lucide-react";
import { Helmet } from "react-helmet";

const ResourcesPage = () => {
  const resources = [
    {
      title: "Gray's Anatomy for Students",
      description: "Comprehensive anatomy textbook with clear illustrations and clinical correlations.",
      category: "book",
      link: "https://www.elsevier.com/books/grays-anatomy-for-students/drake/978-0-323-39304-1",
      thumbnail: "https://images.unsplash.com/photo-1532187643603-ba119ca4109e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80"
    },
    {
      title: "Guyton and Hall Textbook of Medical Physiology",
      description: "The gold standard of physiology textbooks, covering all major body systems.",
      category: "book",
      link: "https://www.elsevier.com/books/guyton-and-hall-textbook-of-medical-physiology/hall/978-0-323-59909-8",
      thumbnail: "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80"
    },
    {
      title: "Complete Anatomy Resource Guide",
      description: "PDF guide covering all essential anatomy concepts with visuals and mnemonics.",
      category: "pdf",
      link: "#",
      thumbnail: "https://images.unsplash.com/photo-1543286386-2e659306cd6c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80"
    },
    {
      title: "Osmosis Medical Videos",
      description: "High-quality medical education videos covering anatomy, physiology, and more.",
      category: "video",
      link: "https://www.osmosis.org/",
      thumbnail: "https://images.unsplash.com/photo-1588196749597-9ff075ee6b5b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80"
    },
    {
      title: "Physiology Review Flashcards",
      description: "Download our comprehensive set of physiology flashcards for quick review.",
      category: "download",
      link: "#",
      thumbnail: "https://images.unsplash.com/photo-1619468129361-605ebea04b44?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80"
    },
    {
      title: "Visible Body",
      description: "Interactive 3D anatomy models and animations for visual learning.",
      category: "website",
      link: "https://www.visiblebody.com/",
      thumbnail: "https://images.unsplash.com/photo-1551884170-09fb70a3a2ed?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80"
    }
  ];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "book":
        return <Book className="h-5 w-5 text-primary" />;
      case "pdf":
        return <FileText className="h-5 w-5 text-red-500" />;
      case "video":
        return <Video className="h-5 w-5 text-green-500" />;
      case "download":
        return <Download className="h-5 w-5 text-amber-500" />;
      case "website":
        return <LinkIcon className="h-5 w-5 text-blue-500" />;
      default:
        return <BookOpen className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <>
      <Helmet>
        <title>Study Resources - DocDot</title>
        <meta 
          name="description" 
          content="Access a curated collection of medical study resources including textbooks, videos, downloadable guides, and more."
        />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        {/* Navigation breadcrumb */}
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="inline-flex items-center px-0">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
        
        {/* Title */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
            <BookOpen className="mr-3 h-8 w-8 text-primary" />
            Study Resources
          </h1>
          <p className="mt-2 text-lg text-gray-600 dark:text-gray-400">
            Curated collection of medical study resources to supplement your learning.
          </p>
        </div>
        
        {/* Resource Categories */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <Button variant="outline" className="flex flex-col items-center py-4 h-auto">
            <Book className="h-5 w-5 mb-2" />
            <span>Books</span>
          </Button>
          <Button variant="outline" className="flex flex-col items-center py-4 h-auto">
            <FileText className="h-5 w-5 mb-2" />
            <span>PDF Guides</span>
          </Button>
          <Button variant="outline" className="flex flex-col items-center py-4 h-auto">
            <Video className="h-5 w-5 mb-2" />
            <span>Videos</span>
          </Button>
          <Button variant="outline" className="flex flex-col items-center py-4 h-auto">
            <Download className="h-5 w-5 mb-2" />
            <span>Downloads</span>
          </Button>
          <Button variant="outline" className="flex flex-col items-center py-4 h-auto">
            <LinkIcon className="h-5 w-5 mb-2" />
            <span>Websites</span>
          </Button>
        </div>
        
        {/* Resources Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource, index) => (
            <Card key={index} className="overflow-hidden flex flex-col h-full">
              <div className="h-48 overflow-hidden">
                <img 
                  src={resource.thumbnail} 
                  alt={resource.title} 
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                />
              </div>
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2 mb-1">
                  {getCategoryIcon(resource.category)}
                  <CardTitle className="text-lg">{resource.title}</CardTitle>
                </div>
                <CardDescription>{resource.description}</CardDescription>
              </CardHeader>
              <CardFooter className="mt-auto pt-4">
                <a 
                  href={resource.link} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-full"
                >
                  <Button variant="outline" className="w-full flex justify-between">
                    <span>
                      {resource.category === "book" ? "View Book" : 
                       resource.category === "pdf" ? "View PDF" : 
                       resource.category === "video" ? "Watch Videos" : 
                       resource.category === "download" ? "Download" : "Visit Website"}
                    </span>
                    <ExternalLink className="h-4 w-4 ml-2" />
                  </Button>
                </a>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        {/* Additional Resources Section */}
        <div className="mt-12">
          <Card>
            <CardHeader>
              <CardTitle>Request Study Materials</CardTitle>
              <CardDescription>Can't find what you're looking for? Let us know what resources would help you.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                We're constantly updating our resource library based on student feedback. If you have suggestions for 
                additional study materials or specific topics you'd like to see covered, please let us know.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a href="mailto:support@docdot.org" className="flex-1">
                  <Button variant="outline" className="w-full">
                    Email Us
                  </Button>
                </a>
                <Link href="/ai-tutor" className="flex-1">
                  <Button className="w-full">
                    Ask Our AI Tutor
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default ResourcesPage;
